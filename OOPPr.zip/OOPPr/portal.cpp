#include <iostream>
#include <vector>
#include <string>
#include <fstream>
using namespace std;

class Person
{
public:
    string name;
    int id;
};

class Student : public Person
{
public:
    string course;
    char grade; // New attribute for simplicity in this example
};

class Teacher : public Person
{
public:
    vector<string> courses;
};

class Course
{
public:
    string name;
    int courseId;

    // Default constructor
    Course() : courseId(0) {}

    // Parameterized constructor
    Course(string n, int id) : name(n), courseId(id) {}
};

class Attendance
{
public:
    int studentId;
    int courseId;
    bool present;
};

class RegistrationPortal
{
private:
    vector<Student> students;
    vector<Teacher> teachers;
    vector<Course> courses;
    vector<Attendance> attendance;

public:
    void addStudent(string name, int id, string course);
    void displayRegisteredStudents();
    void updateStudent(int id, string newName, string newCourse);
    void deleteStudent(int id);
    void addTeacher(string name, int id, vector<string> courses);
    void updateTeacher(int id, string newName, vector<string> newCourses);
    void deleteTeacher(int id);
    void markAttendance(int studentId, int courseId, bool present);
    void displayTeachers();
    void addCourse(string name, int id);
    void updateCourse(int id, string newName);
    void deleteCourse(int id);
    void displayRegisteredCourses();
    void assignGrade(int studentId, int courseId, char grade);
    void displayMenu();
    void UserInput();
    void loadFromFile();
    void saveToFile();
    void updateFile();
};
void RegistrationPortal::loadFromFile()
{
    ifstream file("registration_data.txt");
    if (!file)
    {
        cout << "No previous data found. Starting with an empty database." << endl;
        return;
    }

    int personCount;
    file >> personCount;

    students.resize(personCount);
    for (int i = 0; i < personCount; ++i)
    {
        file >> students[i].name >> students[i].id >> students[i].course >> students[i].grade;
    }

    file >> personCount;
    teachers.resize(personCount);
    for (int i = 0; i < personCount; ++i)
    {
        file >> teachers[i].name >> teachers[i].id;
        int courseCount;
        file >> courseCount;
        teachers[i].courses.resize(courseCount);
        for (int j = 0; j < courseCount; ++j)
        {
            file >> teachers[i].courses[j];
        }
    }

    file >> personCount;
    courses.resize(personCount);
    for (int i = 0; i < personCount; ++i)
    {
        file >> courses[i].name >> courses[i].courseId;
    }

    file >> personCount;
    attendance.resize(personCount);
    for (int i = 0; i < personCount; ++i)
    {
        file >> attendance[i].studentId >> attendance[i].courseId >> attendance[i].present;
    }

    file.close();
}
void RegistrationPortal::saveToFile()
{
    ofstream file("registration_data.txt", ios::app);
    if (!file.is_open())
    {
        cerr << "Error: Unable to save data to file." << endl;
        return;
    }

    // Save student dat
    for (int i = 0; i < students.size(); ++i)
    {
        file << "------STUDENT DATA------" << endl
             << students[i].name << endl
             << students[i].id << endl
             << students[i].course << endl
             << students[i].grade << endl;
    }

    // Save teacher data

    for (int i = 0; i < teachers.size(); ++i)
    {
        file << "------TEACHERS DATA------" << endl
             << teachers[i].name << endl
             << teachers[i].id << endl
             << teachers[i].courses.size() << endl;
        for (int j = 0; j < teachers[i].courses.size(); ++j)
        {
            file << teachers[i].courses[j] << " ";
        }
        file << endl;
    }

    // Save course data
    for (int i = 0; i < courses.size(); ++i)
    {
        file << "------COURSE INFO------" << endl
             << courses[i].name << endl
             << " " << courses[i].courseId << endl;
    }

    // Save attendance data
    for (int i = 0; i < attendance.size(); ++i)
    {
        file << "------ATTENDENCE INFO-----" << endl
             << attendance[i].studentId << endl
             << " " << attendance[i].courseId << endl
             << " " << attendance[i].present << endl;
    }

    file.close();
}

// Function Definitions

void RegistrationPortal::addStudent(string name, int id, string course)
{
    Student newStudent;
    newStudent.name = name;
    newStudent.id = id;
    newStudent.course = course;
    newStudent.grade = -1; // Initialize grade to -1 (not assigned)
    students.push_back(newStudent);
    cout << "Student added successfully." << endl;
    ofstream Outfile("student.txt", ios ::app);
    Outfile << name << " " << id << " " << course << " " << newStudent.grade << endl;
    Outfile.close();
}

void RegistrationPortal::displayRegisteredStudents()
{
    cout << "Registered Students:" << endl;
    ifstream In("student.txt");
    int i = 0;
    while (In >> students[i].name)
    {
        cout << students[i].name << endl;
    }
}
void RegistrationPortal::updateStudent(int id, string newName, string newCourse)
{
    for (int i = 0; i < students.size(); ++i)
    {
        if (students[i].id == id)
        {
            students[i].name = newName;
            students[i].course = newCourse;
            cout << "Student updated successfully." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}
void RegistrationPortal::deleteStudent(int id)
{
    for (int i = 0; i < students.size(); ++i)
    {
        if (students[i].id == id)
        {
            students.erase(students.begin() + i);
            cout << "Student deleted successfully." << endl;
            return;
        }
    }
    cout << "Student not found." << endl;
}

void RegistrationPortal::addTeacher(string name, int id, vector<string> courses)
{
    Teacher newTeacher;
    newTeacher.name = name;
    newTeacher.id = id;
    newTeacher.courses = courses;
    teachers.push_back(newTeacher);
    cout << "Teacher added successfully." << endl;
    ofstream out("teacher.txt", ios ::app);
    out << newTeacher.name << " " << newTeacher.id << endl;
    out.close();
}

void RegistrationPortal::updateTeacher(int id, string newName, vector<string> newCourses)
{
    for (int i = 0; i < teachers.size(); ++i)
    {
        if (teachers[i].id == id)
        {
            teachers[i].name = newName;
            teachers[i].courses = newCourses;
            cout << "Teacher updated successfully." << endl;
            return;
        }
    }
    cout << "Teacher not found." << endl;
}

void RegistrationPortal::deleteTeacher(int id)
{
    for (int i = 0; i < teachers.size(); ++i)
    {
        if (teachers[i].id == id)
        {
            teachers.erase(teachers.begin() + i);
            cout << "Teacher deleted successfully." << endl;
            return;
        }
    }
    cout << "Teacher not found." << endl;
}

void RegistrationPortal::updateFile()
{
    ifstream file("registration_data.txt", ios ::app);
    if (!file.is_open())
    {
        cerr << "Error: Unable to open data file for update." << endl;
        return;
    }

    int personCount;
    file >> personCount;

    // Read and update student data
    for (int i = 0; i < personCount; ++i)
    {
        string dataType;
        file >> dataType;

        if (dataType == "------STUDENT DATA------")
        {
            Student student;
            file >> student.name >> student.id >> student.course >> student.grade;

            // Apply your update logic here
            // For example, let's say you want to increase the grade by 10
            student.grade += 10;

            // Find and update the existing student in your vector
            for (auto &existingStudent : students)
            {
                if (existingStudent.id == student.id)
                {
                    existingStudent = student;
                    break;
                }
            }
        }
    }

    file.close();

    // Now, write the updated data back to the file
    ofstream outFile("registration_data.txt");
    if (!outFile.is_open())
    {
        cerr << "Error: Unable to open data file for update." << endl;
        return;
    }

    // Write the updated student data back to the file
    outFile << students.size() << endl;
    for (const auto &student : students)
    {
        outFile << "------STUDENT DATA------" << endl
                << student.name << endl
                << student.id << endl
                << student.course << endl
                << student.grade << endl;
    }

    // You would need to implement similar logic for other data types (teachers, courses, attendance)

    outFile.close();

    cout << "File updated successfully." << endl;
}

void RegistrationPortal::markAttendance(int studentId, int courseId, bool present)
{
    Attendance newAttendance;
    newAttendance.studentId = studentId;
    newAttendance.courseId = courseId;
    newAttendance.present = present;
    attendance.push_back(newAttendance);
    ofstream Outfile("Attendance.txt", ios ::app);
    Outfile << "Student ID: " << studentId << ", Course ID: " << courseId << endl;
    Outfile.close();
    cout << "Attendance marked successfully." << endl;
}

void RegistrationPortal::displayTeachers()
{

    cout << "Registered Teachers:" << endl;
    ifstream In("teacher.txt");
    int i = 0;
    while (In >> teachers[i].name)
    {
        cout << teachers[i].name << endl;
    }
}
void RegistrationPortal::addCourse(string name, int id)
{
    Course newCourse(name, id);
    courses.push_back(newCourse);
    cout << "Course added successfully." << endl;
    ofstream Outfile("course.txt", ios ::app);
    Outfile << name << " " << id << endl;
    Outfile.close();
}
void RegistrationPortal::updateCourse(int id, string newName)
{
    for (int i = 0; i < courses.size(); ++i)
    {
        if (courses[i].courseId == id)
        {
            courses[i].name = newName;
            cout << "Course updated successfully." << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void RegistrationPortal::deleteCourse(int id)
{
    for (int i = 0; i < courses.size(); ++i)
    {
        if (courses[i].courseId == id)
        {
            courses.erase(courses.begin() + i);
            cout << "Course deleted successfully." << endl;
            return;
        }
    }
    cout << "Course not found." << endl;
}

void RegistrationPortal::displayRegisteredCourses()
{
    cout << "Registered Courses:" << endl;
    ifstream In("course.txt");
    int i = 0;
    while (In >> courses[i].name)
    {
        cout << courses[i].name << endl;
    }
}

void RegistrationPortal::assignGrade(int studentId, int courseId, char grade)
{
    for (int i = 0; i < students.size(); ++i)
    {
        if (students[i].id == studentId && students[i].course == courses[courseId].name)
        {
            students[i].grade = grade;
            cout << "Grade assigned successfully." << endl;
            return;
        }
    }
    cout << "Student or course not found." << endl;
}

void RegistrationPortal::displayMenu()
{
    cout << "\n===== Registration Portal Menu =====" << endl;
    cout << "1. Add Student\n";
    cout << "2. Display Registered Students\n";
    cout << "3. Update Student\n";
    cout << "4. Delete Student\n";
    cout << "5. Add Teacher\n";
    cout << "6. Display Registered Teachers\n";
    cout << "7. Update Teacher\n";
    cout << "8. Delete Teacher\n";
    cout << "9. Mark Attendance\n";
    cout << "10. Add Course\n";
    cout << "11. Update Course\n";
    cout << "12. Delete Course\n";
    cout << "13. Display Registered Courses\n";
    cout << "14. Assign Grade\n";
    cout << "0. Exit\n";
}

void RegistrationPortal::UserInput()
{
    int choice;
    do
    {
        displayMenu();
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            string name, course;
            int id;
            cout << "Enter student name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter student ID: ";
            cin >> id;
            cout << "Enter student course: ";
            cin.ignore();
            getline(cin, course);
            addStudent(name, id, course);
            break;
        }
        case 2:
            displayRegisteredStudents();
            break;
        case 3:
        {
            int id;
            string newName, newCourse;
            cout << "Enter student ID to update: ";
            cin >> id;
            cout << "Enter new name: ";
            cin.ignore();
            getline(cin, newName);
            cout << "Enter new course: ";
            getline(cin, newCourse);
            updateStudent(id, newName, newCourse);
            break;
        }
        case 4:
        {
            int id;
            cout << "Enter student ID to delete: ";
            cin >> id;
            deleteStudent(id);
            break;
        }
        case 5:
        {
            string name;
            int id;
            vector<string> courses;
            cout << "Enter teacher name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter teacher ID: ";
            cin >> id;
            cout << "Enter teacher courses (space-separated): ";
            cin.ignore();
            string course;
            cin >> course;
            addTeacher(name, id, courses);
            break;
        }
        case 6:
            displayTeachers();
            break;
        case 7:
        {
            int id;
            string newName;
            vector<string> newCourses;
            cout << "Enter teacher ID to update: ";
            cin >> id;
            cout << "Enter new name: ";
            cin.ignore();
            getline(cin, newName);
            cout << "Enter new courses (space-separated): ";
            cin.ignore();
            string course;
            cin >> course;
            newCourses.push_back(course);
            updateTeacher(id, newName, newCourses);
            break;
        }
        case 8:
        {
            int id;
            cout << "Enter teacher ID to delete: ";
            cin >> id;
            deleteTeacher(id);
            break;
        }
        case 9:
        {
            int studentId, courseId;
            bool present;
            cout << "Enter student ID: ";
            cin >> studentId;
            cout << "Enter course ID: ";
            cin >> courseId;
            cout << "Is the student present? (1 for Yes, 0 for No): ";
            cin >> present;
            markAttendance(studentId, courseId, present);
            break;
        }
        case 10:
        {
            string name;
            int id;
            cout << "Enter course name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter course ID: ";
            cin >> id;
            addCourse(name, id);
            break;
        }
        case 11:
        {
            int id;
            string newName;
            cout << "Enter course ID to update: ";
            cin >> id;
            cout << "Enter new name: ";
            cin.ignore();
            getline(cin, newName);
            updateCourse(id, newName);
            break;
        }
        case 12:
        {
            int id;
            cout << "Enter course ID to delete: ";
            cin >> id;
            deleteCourse(id);
            break;
        }
        case 13:
            displayRegisteredCourses();
            break;
        case 14:
        {
            int studentId, courseId;
            char grade;
            cout << "Enter student ID: ";
            cin >> studentId;
            cout << "Enter course ID: ";
            cin >> courseId;
            cout << "Enter grade: ";
            cin >> grade;
            assignGrade(studentId, courseId, grade);
            break;
        }
        case 0:
            cout << "Exiting the program. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
            break;
        }
    } while (choice != 0);
}
class Access : public RegistrationPortal
{
protected:
    struct info
    {
        string id;
        string pass;
    };
    info oldUser;
    info newUser;
    info check_info;
    ofstream outfile;
    ifstream infofile;
    bool loginSuccessful = false;
    int ask;

public:
    Access() : ask(0)
    {
        outfile.open("data.txt", ios::app);
        infofile.open("data.txt");
    }
    void logIn();
    void signIn();
    void display()
    {
        cout << " Enter for following." << endl;
        cout << " Press 1 for SignUp" << endl;
        cout << " Press 2 for LogIn" << endl;
        cout << " Press 3 for exit" << endl;
        cout << " ";
        cin >> ask;

        system("cls");
        if (ask == 1)
        {
            signIn();
            display();
        }
        else if (ask == 2)
        {
            logIn();
            if (loginSuccessful)
            {
                UserInput();
            }
        }
        else if (ask == 3)
        {
            cout << " GOODBYE <3" << endl;
            exit(0);
        }

        else
        {
            cout << " Invalid Choice! Try Again" << endl;
            cin.ignore(); // Clear the input buffer
            display();
        }
    }
};
void Access::logIn()
{

    cout << " Enter username: ";
    cin >> oldUser.id;
    do
    {
        cout << endl;
        oldUser.pass = "";
        cout << " Enter password: ";
        cin >> oldUser.pass;
        cout << endl;
        if (oldUser.pass.empty()) // agr password wali blank khaali haii
        {
            cout << " Password cannot be empty. Please enter a password." << endl;
            continue; // loop shuro se shuro hojayegi //
        }
        loginSuccessful = false;
        infofile.clear(); // Clear any error flags
        infofile.seekg(0, ios::beg);
        while (infofile >> check_info.id >> check_info.pass)
        {
            if (oldUser.id == check_info.id && oldUser.pass == check_info.pass)
            {
                cout << " Login Done" << endl;
                system("cls");
                loginSuccessful = true;
                break;
            }
        }

        if (!loginSuccessful)
        {
            cout << " Try Again" << endl;
        }
        infofile.clear();
        infofile.seekg(0, ios::beg);

    } while (!loginSuccessful);
    infofile.close();
}
void Access ::signIn()
{
    cout << "\n Enter your name: ";
    cin >> newUser.id;
    if (infofile.is_open())
    {
        infofile.clear();            // Clear the end-of-file flag
        infofile.seekg(0, ios::beg); // Move the file pointer to the beginning taky file ko start se read kry
        while (infofile >> check_info.id >> check_info.pass)
            if (newUser.id == check_info.id)
            {
                infofile.clear(); // Clear the end-of-file flag
                infofile.seekg(0, ios::beg);
                cout << " Enter different name, This name already exists" << endl;
                cout << " Enter your name: ";
                cin >> newUser.id;
            }
    }
    do
    {
        cout << " Enter your pin: ";
        cin >> newUser.pass;
        cout << endl;
        if (newUser.pass.empty())
        {
            cout << " Password cannot be empty. Please enter a password." << endl;
            continue;
        }
    } while (newUser.pass.empty());

    outfile.clear();
    if (outfile.is_open())
    {
        outfile << newUser.id << " " << newUser.pass << endl;
        cout << " SignIn Complete." << endl;
        system("cls");
    }
    else
    {
        cout << " Error Occured while signing In" << endl;
    }
}
int main()
{
    Access obj;
    obj.display();
    RegistrationPortal portal;
    portal.loadFromFile(); // Load data from file
    

    portal.saveToFile();
    portal.updateFile();
    return 0;
}
